package com.example.paul.studentbookandmore.ui.activity.save;

/**
 * Created by Paul on 19-Jul-17.
 */

public interface SaveDisciplinePresenter {

    void addDiscipline();
}

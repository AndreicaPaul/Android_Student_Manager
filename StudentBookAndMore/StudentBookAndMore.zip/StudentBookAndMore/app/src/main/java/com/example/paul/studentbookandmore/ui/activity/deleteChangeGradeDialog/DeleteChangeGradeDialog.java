package com.example.paul.studentbookandmore.ui.activity.deleteChangeGradeDialog;

import com.example.paul.studentbookandmore.model.Grade;

/**
 * Created by Paul on 20-Sep-17 at 1:23 PM.
 */

public interface DeleteChangeGradeDialog {

}

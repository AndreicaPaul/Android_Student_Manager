package com.example.paul.studentbookandmore.ui.activity.delete;

import android.widget.ListView;

/**
 * Created by Paul on 15-Sep-17 at 4:50 PM.
 */

public interface SelectDisciplineToDeletePresenter {

    void setListItems();
    void ListItemSelected(int position);
}

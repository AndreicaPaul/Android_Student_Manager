# Smart Mark
A simple app, giving students and pupils the possibility to save their grades view their schedule and more!
